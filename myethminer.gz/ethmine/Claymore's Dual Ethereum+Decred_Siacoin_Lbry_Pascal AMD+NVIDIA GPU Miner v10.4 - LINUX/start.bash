export GPU_FORCE_64BIT_PTR 0
export GPU_MAX_HEAP_SIZE 100
export GPU_USE_SYNC_OBJECTS 1
export GPU_MAX_ALLOC_PERCENT 100
export GPU_SINGLE_ALLOC_PERCENT 100
./ethdcrminer64 -epool eth-us-east1.nanopool.org:9999 -ewal 0x0b0f4c31d349c73d833cb5772ab040bb831e0b17.VilRig1/vilish@gmail.com -epsw x -mode 1 -ftime 10